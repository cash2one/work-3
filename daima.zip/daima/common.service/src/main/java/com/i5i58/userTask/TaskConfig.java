package com.i5i58.userTask;

/**
 * @author songfl
 * 骞冲彴浠诲姟閰嶇疆
 */
public class TaskConfig {

//	public TaskConfig.TaskType getTaskTypeByType(int taskType) {
//		// TODO Auto-generated constructor stub
//		if (TaskType.TLogonEveryDay.getTaskType() == taskType)
//			return TaskType.TLogonEveryDay;
//		
//		if (TaskType.TWatchChannelEveryHour.getTaskType() == taskType)
//			return TaskType.TWatchChannelEveryHour;
//		
//		if (TaskType.TFirstTimeSetFaceImage.getTaskType() == taskType)
//			return TaskType.TFirstTimeSetFaceImage;
//		
//		if (TaskType.TFirstTimeWatchChannel.getTaskType() == taskType)
//			return TaskType.TFirstTimeWatchChannel;
//		
//		if (TaskType.TFirstTimeFollowAnchor.getTaskType() == taskType)
//			return TaskType.TFirstTimeFollowAnchor;
//		
//		if (TaskType.TFirstTimeUpdateStatus.getTaskType() == taskType)
//			return TaskType.TFirstTimeUpdateStatus;
//		
//		if (TaskType.TFirstTimeUploadScreenshot.getTaskType() == taskType)
//			return TaskType.TFirstTimeUploadScreenshot;
//		if (TaskType.TLogonEveryDay.getTaskType() == taskType)
//			return TaskType.TLogonEveryDay;
//		if (TaskType.TLogonEveryDay.getTaskType() == taskType)
//			return TaskType.TLogonEveryDay;
//		if (TaskType.TLogonEveryDay.getTaskType() == taskType)
//			return TaskType.TLogonEveryDay;
//		if (TaskType.TLogonEveryDay.getTaskType() == taskType)
//			return TaskType.TLogonEveryDay;
//		if (TaskType.TLogonEveryDay.getTaskType() == taskType)
//			return TaskType.TLogonEveryDay;
//	}
	
	public enum TaskType{		
		TLogonEveryDay(1, 10, 10, false),//姣忔棩棣栨鐧诲綍锛岃幏寰�10缁忛獙
		TWatchChannelEveryHour(2, 10, 0, false),//姣忚鐪嬩竴灏忔椂锛岃幏寰�10缁忛獙
		
		/**
		 * TFirstTime*琛ㄧず浠呭湪绗竴娆″畬鎴愮殑鏃跺�欎細鑾峰緱绉垎锛屾棤娉曢噸澶嶈幏寰�; 姣忓畬鎴愪竴椤癸紝鑾峰緱100绉垎;
		 * */
		TFirstTimeSetFaceImage(3, 100, 100, true),
		TFirstTimeWatchChannel(4, 100, 100, true),
		TFirstTimeFollowAnchor(5, 100, 100, true),
		TFirstTimeUpdateStatus(6, 100, 100, true),
		TFirstTimeUploadScreenshot(7, 100, 100, true),
		TFirstTimeUploadShortFilm(8, 100, 100, true),
		TFirstTimeLeaveMessage(9, 100, 100, true),
		
		/**
		 * 杞彂鐩存挱闂撮摼鎺�,姣忚浆鍙�1涓幏寰�100绉垎锛岄�氳繃杞彂鑾峰緱绉垎鐨勬瘡鏃ヤ笂闄愭槸1000绉垎
		 * */
		TShareChannelLink(10, 100, 1000, false),
		/**
		 * 鍒嗗埆浣跨敤鎵嬫満绔紝PC绔拰web绔笁涓鍙ｇ櫥闄嗚繃鍚庯紝鑾峰緱1000绉垎
		 * */
		TFirstTimeLogonMobile(11, 1000, 1000, true),
		TFirstTimeLogonPC(12, 1000, 1000, true),
		TFirstTimeLogonWeb(13, 1000, 1000, true),
		
		/**
		 * 姣忔坊鍔犱竴鍚嶅ソ鍙嬶紝鑾峰緱10绉垎锛屼笂闄愭槸1000
		 * */
		TAddFriend(14, 10, 1000, false);
		
		
		int taskType;	//浠诲姟绫诲瀷
		long taskScore; //瀹屾垚涓�娆′换鍔″彲鑾峰緱鐨勭Н鍒�
		long maxScore;  //姣忓ぉ鏈�澶氱疮璁＄殑绉垎涓婇檺,0琛ㄧず娌℃湁涓婇檺
		boolean isOnlyFirstTime; //浠诲姟鍙墽琛屼竴娆�
		
		TaskType(int taskType, long taskScore, long maxScore, boolean isOnlyFirstTime){
			this.taskType = taskType;
			this.taskScore = taskScore;
			this.maxScore = maxScore;
			this.isOnlyFirstTime = isOnlyFirstTime;
		}
		
		public int getTaskType() {
			return taskType;
		}

		public void setTaskType(int taskType) {
			this.taskType = taskType;
		}

		public long getTaskScore() {
			return taskScore;
		}

		public void setTaskScore(long taskScore) {
			this.taskScore = taskScore;
		}

		public long getMaxScore() {
			return maxScore;
		}

		public void setMaxScore(long maxScore) {
			this.maxScore = maxScore;
		}

		public boolean isOnlyFirstTime() {
			return isOnlyFirstTime;
		}

		public void setOnlyFirstTime(boolean isOnlyFirstTime) {
			this.isOnlyFirstTime = isOnlyFirstTime;
		}
		
	}
}
