package com.i5i58.apis.security;

import com.i5i58.apis.constants.ResultDataSet;

public interface IOssAccessControl {

	ResultDataSet getUploadAuthority();
}
