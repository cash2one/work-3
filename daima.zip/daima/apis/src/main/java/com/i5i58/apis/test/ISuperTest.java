package com.i5i58.apis.test;

import com.i5i58.apis.constants.ResultDataSet;

public interface ISuperTest {
	ResultDataSet test(String name, int age,String clientIp,String clientIpYun); 
}
