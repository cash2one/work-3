package com.i5i58.apis.platform;

import java.io.IOException;

import com.i5i58.apis.constants.ResultDataSet;

public interface IPlatformAnchorAdmin {

	/**
	 * 工作人员审核主播认证
	 * 
	 * @author frank
	 * @param superAccid
	 * @param accId
	 * @param agree
	 * @return
	 * @throws IOException
	 */
	ResultDataSet verifyAnchorAuth(String superAccid, String accId, boolean agree) throws IOException;

	/**
	 * 主播公告
	 * 
	 * @author frank
	 * @param superAccid
	 * @param title
	 * @param content
	 * @return
	 * @throws IOException
	 */
	ResultDataSet noticeAnchor(String superAccid, String title, String content) throws IOException;

	/**
	 * 按ID，名称等查询主播
	 * 
	 * @author frank
	 * @param param
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws IOException
	 */
	ResultDataSet queryAnchorList(String param, int pageSize, int pageNum) throws IOException;

	/**
	 * 查询主播审核列表
	 * 
	 * @param sortDir
	 *            asc,desc
	 * @param pageSize
	 * @param pageNum
	 * @return
	 * @throws IOException
	 */
	ResultDataSet queryAnchorVerifyList(String sortDir, int pageSize, int pageNum) throws IOException;

	/**
	 * 获取主播信息
	 * 
	 * @param accId
	 * @return
	 * @throws IOException
	 */
	ResultDataSet getAnchorInfo(String accId) throws IOException;

	/**
	 * 获取主播所属公会和所拥有的频道
	 * 
	 * @param accId
	 * @return
	 * @throws IOException
	 */
	ResultDataSet getAnchorChannelAndGroup(String accId) throws IOException;
	
	/**
	 * 获取主播直播历史记录
	 * 
	 * @author songfl
	 * @param accId
	 * @param fromTime 本次查询的最早开播时间，毫秒
	 * @param toTime 本次查询的最晚开播时间，毫秒
	 * */
	public ResultDataSet getAnchorPushRecord(String accId, long fromTime, long toTime);
	
	/**
	 * 统计主播直播时长
	 * @author songfl
	 * @param fromTime 本次统计的最早开播时间，毫秒
	 * @param toTime 本次统计的最晚开播时间，毫秒
	 * */
	public ResultDataSet calcAnchorActiveTime(String accId, long fromTime, long toTime);
}
