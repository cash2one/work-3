package com.i5i58.apis.social;

import com.i5i58.apis.constants.ResultDataSet;

public interface ISubGameInfo {

	ResultDataSet getSubGameInfo(String openId, String password);
}
