package com.i5i58.secondary.dao.wechat;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.i5i58.data.account.Account;
import com.i5i58.data.wechat.WechatAccount;

public interface WechatAccountSecDao extends PagingAndSortingRepository<WechatAccount, String>{

	public Account findByOpenIdAndSelected(String openId, boolean selected);
}
