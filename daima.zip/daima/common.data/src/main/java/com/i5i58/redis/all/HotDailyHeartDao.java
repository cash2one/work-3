package com.i5i58.redis.all;

import org.springframework.data.repository.CrudRepository;

import com.i5i58.data.account.HotDailyHeart;

public interface HotDailyHeartDao extends CrudRepository<HotDailyHeart, String> {

}
