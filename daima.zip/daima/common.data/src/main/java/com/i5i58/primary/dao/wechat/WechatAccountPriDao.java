package com.i5i58.primary.dao.wechat;

import java.util.List;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.i5i58.data.account.Account;
import com.i5i58.data.wechat.WechatAccount;

public interface WechatAccountPriDao extends PagingAndSortingRepository<WechatAccount, String> {

	public WechatAccount findByOpenIdAndSelected(String openId, boolean selected);

	public WechatAccount findByOpenIdAndAccId(String openId, String accId);

	public List<WechatAccount> findByOpenId(String openId);

	public WechatAccount findAccIdByOpenId(String openId);
	

}