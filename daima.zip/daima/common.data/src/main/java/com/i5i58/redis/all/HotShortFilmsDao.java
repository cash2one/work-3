package com.i5i58.redis.all;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.i5i58.data.social.HotShortFilms;

public interface HotShortFilmsDao extends PagingAndSortingRepository<HotShortFilms, String> {

}
