package com.i5i58.primary.dao.superAdmin;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.i5i58.data.superAdmin.SuperAdminRecord;

public interface SuperAdminRecordPriDao extends PagingAndSortingRepository<SuperAdminRecord, Long> {

}
