package com.i5i58.primary.dao.config;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.i5i58.data.config.ReactNativeVersionConfig;

public interface ReactNativeVersionConfigPriDao extends PagingAndSortingRepository<ReactNativeVersionConfig, String> {


}
