package com.i5i58.secondary.dao.pay;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.i5i58.data.pay.OnLineOrder;
/**
 * 
 * @author cw
 *
 */
public interface OnLineOrderSecDao extends PagingAndSortingRepository<OnLineOrder, String>{
	Page<OnLineOrder> findByAccId(String accId, Pageable pageable);
}
