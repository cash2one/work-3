package com.i5i58.primary.dao.account;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.i5i58.data.account.BusinessAgent;

public interface BusinessAgentPriDao extends PagingAndSortingRepository<BusinessAgent, String> {

}
