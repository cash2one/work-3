package com.i5i58.secondary.dao.record;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.i5i58.data.record.MoneyFlow;
import com.i5i58.data.record.MoneyFlowType;

public interface MoneyFlowSecDao extends PagingAndSortingRepository<MoneyFlow, Long> {
	Page<MoneyFlow> findByAccId(String accId, Pageable pageable);

	List<MoneyFlow> findByAccIdAndType(String accId, int type);
}
