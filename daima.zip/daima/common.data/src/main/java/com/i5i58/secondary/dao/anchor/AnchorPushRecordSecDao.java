package com.i5i58.secondary.dao.anchor;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.i5i58.data.anchor.AnchorPushRecord;

@Transactional
public interface AnchorPushRecordSecDao extends PagingAndSortingRepository<AnchorPushRecord, Long> {
	
	@Query("select a from AnchorPushRecord a where a.accId = ?1 and a.openTime >= ?2 and a.openTime <= ?3 and (a.ignored = false or a.ignored is null)")
	List<AnchorPushRecord> findByTime(String accId, long fromTime, long toTime);
}
