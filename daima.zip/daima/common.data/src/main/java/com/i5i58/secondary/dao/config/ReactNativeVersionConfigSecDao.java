package com.i5i58.secondary.dao.config;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.i5i58.data.config.ReactNativeVersionConfig;

public interface ReactNativeVersionConfigSecDao extends PagingAndSortingRepository<ReactNativeVersionConfig, String> {


}
