package com.i5i58.secondary.dao.social;

import org.springframework.data.repository.CrudRepository;

import com.i5i58.data.social.SocialVersion;

public interface SocialVersionSecDao extends CrudRepository<SocialVersion, String> {

}
