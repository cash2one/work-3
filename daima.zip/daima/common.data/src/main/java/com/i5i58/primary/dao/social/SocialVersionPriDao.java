package com.i5i58.primary.dao.social;

import org.springframework.data.repository.CrudRepository;

import com.i5i58.data.social.SocialVersion;

public interface SocialVersionPriDao extends CrudRepository<SocialVersion, String> {

}
