package com.i5i58.secondary.dao.account;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;

import com.i5i58.data.account.Wallet;

@Transactional
public interface WalletSecDao extends CrudRepository<Wallet, String> {

	Wallet findByAccId(String accId);
}
