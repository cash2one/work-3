package com.i5i58.primary.dao.pay;

import org.springframework.data.repository.CrudRepository;

import com.i5i58.data.pay.OnLineOrder;
/**
 * 
 * @author cw
 *
 */
public interface OnLineOrderPriDao extends CrudRepository<OnLineOrder, String>{

}
